/*******************************************************/
/**  generated lexicon data file from cmu    */
/*******************************************************/

const unsigned char cmu_lex_data[] = 
{
   0,
#include "cmu_lex_data_raw.c"
};

