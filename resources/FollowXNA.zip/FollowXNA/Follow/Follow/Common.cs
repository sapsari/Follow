﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Follow
{
    public static class Common
    {
        static Random random = new Random();


        public static String[] topWelcomeMessages = { "Press any key to join. Everyone is welcomed.", "Press any key to join. Everyone is welcomed!" };
        public static String[] orderMessages = { "Follow me plz", "Follow ME!", "Follow me", "Plz follow me", "FOLLOW ME!!!"};
        public static String[] followerIntroductionMessages = { "{0} following", "I'm Mrs {0}", "Me Junior {0}", "I am princess {0}", "Mr {0} here" };
        public static String[] theyVoices = { "heyyyyyyyyyyyyyyyyyyyyy", "yoooooooooooooooooooooo", "vuuuuuuuuuuuuuuuuuuuuuu", "meeeeeeeeeeeeeeeeeeeeee", "biiiiiiiiiiiiiiiiiiiiii" };

        public static String NextRandomMessage(this String[] stringArray)
        {
            return stringArray[Common.random.Next(stringArray.Length)];
        }


        /// <summary>
        /// distribute the followers on the earth more precisely with randomness
        /// </summary>
        /// <param name="followers"></param>
        /// <returns></returns>
        public static double NextFollowerAngle(List<Dude> followers)
        {
            List<int> unoccupiedSlots = new List<int>();
            int count = followers.Count + 1;
            double pieAngle = Math.PI * 2 / count;
            for (int i = 0; i < count; i++)
            {
                double minAngle = pieAngle * i;
                double maxAngle = pieAngle * (i + 1);
                bool isOccupied = false;
                foreach (var follower in followers)
                {
                    if (follower.angle >= minAngle && follower.angle <= maxAngle)
                    {
                        isOccupied = true;
                        break;
                    }
                }
                if (!isOccupied)
                    unoccupiedSlots.Add(i);
            }
            if (unoccupiedSlots.Count > 0)
            {
                int pie = random.Next(unoccupiedSlots.Count);
                return random.NextDouble() * pieAngle + unoccupiedSlots[pie] * pieAngle;
            }
            else
            {
                return Follower.random.NextDouble() * Math.PI * 2;
            }
        }



        public static Color Brighten(this Color color)
        {
            const int colorBrightenValue = 30;
            color.R = (byte)Math.Min(255, color.R + colorBrightenValue);
            color.G = (byte)Math.Min(255, color.G + colorBrightenValue);
            color.B = (byte)Math.Min(255, color.B + colorBrightenValue);
            return color;
        }

        public static Color Darken(this Color color)
        {
            const int colorDarkenValue = 30;
            color.R = (byte)Math.Max(0, color.R - colorDarkenValue);
            color.G = (byte)Math.Max(0, color.G - colorDarkenValue);
            color.B = (byte)Math.Max(0, color.B - colorDarkenValue);
            return color;
        }

    }
}
