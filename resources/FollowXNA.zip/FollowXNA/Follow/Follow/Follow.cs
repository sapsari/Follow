using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Follow
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Follow : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        private Texture2D earthSpriteTexture;
        private Rectangle earthRectangle;
        Texture2D spriteTextureWhite;

        SpriteFont font1;
        Vector2 topTextPosition;
        String topText;
        Vector2 bottomTextPosition;
        String bottomText;

        List<Dude> they = new List<Dude>();
        List<Dude> followers = new List<Dude>();

        private static System.Timers.Timer aTimer;

        public Follow()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
#if DEBUG
            this.IsMouseVisible = true;
#endif
            this.IsFixedTimeStep = false;
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
#if DEBUG
            graphics.PreferredBackBufferWidth = 1024;
            graphics.PreferredBackBufferHeight = 768;
            graphics.IsFullScreen = false;
            graphics.ApplyChanges();
#else
            graphics.PreferredBackBufferWidth = GraphicsDevice.DisplayMode.Width;
            graphics.PreferredBackBufferHeight = GraphicsDevice.DisplayMode.Height;
            graphics.IsFullScreen = true;
            graphics.ApplyChanges();

#endif

            Follower.screenCenter = new Vector2(
                graphics.GraphicsDevice.Viewport.Width / 2,
                graphics.GraphicsDevice.Viewport.Height / 2);


            {
                // Create a timer with a ten second interval.
                aTimer = new System.Timers.Timer(3000);
                // Hook up the Elapsed event for the timer.
                aTimer.Interval = 3000;;
                aTimer.Elapsed += new System.Timers.ElapsedEventHandler(aTimer_Elapsed);
                aTimer.Enabled = true;
                aTimer_Elapsed(null, null);
            }


            base.Initialize();
        }

        void aTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            topText = Common.topWelcomeMessages.NextRandomMessage();

            if (followers.Count == 0)
                bottomText = "Press any key to start following Him";
            if (followers.Count > 0 && Dude.random.NextDouble() > 0.4)
                bottomText = "Press other keys to join following Him";
            if (they.Count > 1 && Dude.random.NextDouble() > 0.7)
                bottomText = "Follow the One in front of you";
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            spriteTextureWhite = Content.Load<Texture2D>("white");

            {
                earthSpriteTexture = Content.Load<Texture2D>("earth");
                double sizeMultiplier = 1.5;
                earthRectangle = new Rectangle(
                    (int)((graphics.GraphicsDevice.Viewport.Width - earthSpriteTexture.Width * sizeMultiplier) / 2),
                    (int)((graphics.GraphicsDevice.Viewport.Height - earthSpriteTexture.Height * sizeMultiplier) / 2),
                    (int)(earthSpriteTexture.Width * sizeMultiplier), (int)(earthSpriteTexture.Height * sizeMultiplier));
            }

            {
                they.Add(new Him(this, spriteBatch, null, they));
            }

            // Create a new SpriteBatch, which can be used to draw textures.
            font1 = Content.Load<SpriteFont>("SpriteFont1");
        
            topTextPosition = new Vector2(graphics.GraphicsDevice.Viewport.Width / 2, 50);
            bottomTextPosition = new Vector2(graphics.GraphicsDevice.Viewport.Width / 2, graphics.GraphicsDevice.Viewport.Height - 50);
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // update dudes
            foreach (Him him in they)
            {
                him.Update(gameTime);
            }
            foreach (Follower follower in followers)
            {
                follower.Update(gameTime);
            }

            // remove inactive followers
            for (int i = 0; i < followers.Count; i++)
            {
                Follower follower = (Follower)followers[i];
                if (follower.isKeyDown)
                    follower.lastKeyDownTimeInSeconds = gameTime.TotalGameTime.TotalSeconds;
                else
                {
                    if (gameTime.TotalGameTime.TotalSeconds - follower.lastKeyDownTimeInSeconds > follower.DisappearTimeInSeconds)
                        followers.Remove(follower);
                }
            }

            // remove unfollowed Hims
            for (int i = 0; i < they.Count; i++)
            {
                Him him = (Him)they[i];
                bool hasActiveFollower = false;
                foreach (var follower in him.followers)
                {
                    hasActiveFollower = hasActiveFollower || follower.FollowRatio > 0.8;
                }
                if (hasActiveFollower)
                    him.lastKeyDownTimeInSeconds = gameTime.TotalGameTime.TotalSeconds;
                else
                {
                    if (gameTime.TotalGameTime.TotalSeconds - him.lastKeyDownTimeInSeconds > him.DisappearTimeInSeconds)
                        they.Remove(him);
                }
            }

            // increase Him if necessary
            while (they.Count <= followers.Count / 5 && they.Count < 5)
            {
                they.Add(new Him(this, spriteBatch, gameTime, they));
            }

            // determine which follower follows which Him
            {
                foreach (var follower in followers)
                {
                    follower.angle = follower.angle % (Math.PI * 2);
                }
                foreach (var him in they)
                {
                    him.angle = him.angle % (Math.PI * 2);
                }
                foreach (Follower follower in followers)
                {
                    double minAngle = 20;
                    Him following = null;
                    foreach (Him him in they)
                    {
                        double angle = him.angle - follower.angle;
                        if (angle < 0)
                            angle += Math.PI * 2;
                        if (angle < minAngle)
                        {
                            minAngle = angle;
                            following = him;
                        }
                    }
                    follower.him = following;
                    //if (following != null)
                    //{
                    //    follower.message = following.message;
                    //}
                }
            }

            UpdateInput(gameTime);

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            spriteBatch.Begin();


            //spriteBatch.Draw(SpriteTexture, TitleSafe, null, Color.White, 0, new Vector2(TitleSafe.Center.X, TitleSafe.Center.Y), SpriteEffects.None, 0);
            spriteBatch.Draw(earthSpriteTexture, earthRectangle, null, Color.White, 0, Vector2.Zero, SpriteEffects.None, 0);

            foreach (Him him in they)
            {
                him.Draw(gameTime);
            }

            foreach (Follower follower in followers)
            {
                follower.Draw(gameTime);
            }

            if (they.Count > 0)
            {
                // Draw Hello World
                // string output = "Hello World";
                //string output = Deneme().ToString();
                string output = topText;

                // Find the center of the string
                Vector2 fontOrigin = font1.MeasureString(output) / 2;
                {
                    Vector2 position = topTextPosition;
                    spriteBatch.Draw(spriteTextureWhite,
                        new Rectangle((int)position.X - (int)fontOrigin.X - 1 - 10, (int)position.Y - (int)fontOrigin.Y - 1 - 5, (int)fontOrigin.X * 2 + 22, (int)fontOrigin.Y * 2 + 12),
                        null,
                        Color.Black, 0, Vector2.Zero, SpriteEffects.None, 0);
                    spriteBatch.Draw(spriteTextureWhite,
                        new Rectangle((int)position.X - (int)fontOrigin.X - 10, (int)position.Y - (int)fontOrigin.Y - 5, (int)fontOrigin.X * 2 + 20, (int)fontOrigin.Y * 2 + 10),
                        null,
                        they[0].CurrentColor, 0, Vector2.Zero, SpriteEffects.None, 0);
                }

                // Draw the string
                spriteBatch.DrawString(font1, output, topTextPosition, Color.White, 0, fontOrigin, 1.0f, SpriteEffects.None, 0.5f);
            }

            if (they.Count > 0)
            {
                // Draw Hello World
                // string output = "Hello World";
                //string output = Deneme().ToString();
                string output = bottomText;

                // Find the center of the string
                Vector2 fontOrigin = font1.MeasureString(output) / 2;
                {
                    Vector2 position = bottomTextPosition;
                    spriteBatch.Draw(spriteTextureWhite,
                        new Rectangle((int)position.X - (int)fontOrigin.X - 1 - 10, (int)position.Y - (int)fontOrigin.Y - 1 - 5, (int)fontOrigin.X * 2 + 22, (int)fontOrigin.Y * 2 + 12),
                        null,
                        Color.Black, 0, Vector2.Zero, SpriteEffects.None, 0);
                    spriteBatch.Draw(spriteTextureWhite,
                        new Rectangle((int)position.X - (int)fontOrigin.X - 10, (int)position.Y - (int)fontOrigin.Y - 5, (int)fontOrigin.X * 2 + 20, (int)fontOrigin.Y * 2 + 10),
                        null,
                        they[0].CurrentColor, 0, Vector2.Zero, SpriteEffects.None, 0);
                }

                // Draw the string
                spriteBatch.DrawString(font1, output, bottomTextPosition, Color.White, 0, fontOrigin, 1.0f, SpriteEffects.None, 0.5f);

            }


            //if (followers.Count > 0)
            //{
            //    string debugString = ((Follower)followers[0]).FollowRatio.ToString();
            //    Vector2 fontOrigin = font1.MeasureString(debugString) / 2;
            //    spriteBatch.DrawString(font1, debugString, topTextPosition, Color.White, 0, fontOrigin, 1.0f, SpriteEffects.None, 0.5f);
            //}


            //{
            //    string debugString = gameTime.TotalGameTime.TotalSeconds.ToString();
            //    Vector2 fontOrigin = font1.MeasureString(debugString) / 2;
            //    spriteBatch.DrawString(font1, debugString, topTextPosition, Color.White, 0, fontOrigin, 1.0f, SpriteEffects.None, 0.5f);
            //}


            //if (they.Count > 0)
            //{
            //    string debugString = (they[0].angle /Math.PI * 180).ToString();
            //    Vector2 fontOrigin = font1.MeasureString(debugString) / 2;
            //    spriteBatch.DrawString(font1, debugString, topTextPosition, Color.White, 0, fontOrigin, 1.0f, SpriteEffects.None, 0.5f);
            //}


            //if (followers.Count > 0)
            //{
            //    string debugString = ((Follower)followers[0]).CurrentColor.ToString();
            //    Vector2 fontOrigin = font1.MeasureString(debugString) / 2;
            //    spriteBatch.DrawString(font1, debugString, topTextPosition, Color.White, 0, fontOrigin, 1.0f, SpriteEffects.None, 0.5f);
            //}

            


            spriteBatch.End();
            base.Draw(gameTime);
        }

        void UpdateInput(GameTime gameTime)
        {
            KeyboardState keyboardState = Keyboard.GetState();
            MouseState mouseState = Mouse.GetState();

            Keys[] keys = keyboardState.GetPressedKeys();

            foreach (Keys key in keys)
            {
                bool hasFollowerWithKey = false;
                foreach (Follower follower in followers)
                {
                    if (follower.key == key)
                    {
                        hasFollowerWithKey = true;
                        break;
                    }
                }
                if (!hasFollowerWithKey)
                {
                    followers.Add(new Follower(this, spriteBatch, gameTime, followers, key, (Him)they[0]));
                }
            }

            foreach (Follower follower in followers)
            {
                follower.isKeyDown = keyboardState.IsKeyDown((Keys)follower.key);
            }
        }


        Object Deneme()
        {
            String dene = "";
            foreach (Follower follower in followers)
            {
                dene += "[" + follower.key + "]";//[" + follower.angle + "]";
            }
            return dene;
        }

        //Object Deneme2()
        //{
        //    String dene = "";
        //    foreach (Keys key in tempKeys)
        //    {
        //        dene += "[" + key + "]";
        //    }
        //    return dene;
        //}


    }
}
