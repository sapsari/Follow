﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.Speech.Synthesis;

namespace Follow
{
    public class Him : Dude
    {

        List<int> rhythmTimes; // in milliseconds
        public int totalRhythmTime;


        int currentRhythmIndex;
        int currentRhythmElapsedTime; // in milliseconds


        public List<Follower> followers = new List<Follower>();

        SpeechSynthesizer ss = new SpeechSynthesizer();
        string voice;

        

        public Him(Game game, SpriteBatch spriteBatch, GameTime gameTime, List<Dude> others)
            : base(game, spriteBatch, gameTime, others)
        {
            message = Common.orderMessages.NextRandomMessage();
            voice = Common.theyVoices.NextRandomMessage();

            currentRhythmIndex = 0;
            currentRhythmElapsedTime = 0;
            rhythmTimes = new List<int>();

            int rhythmCount = 4 + random.Next(3);

            while (rhythmCount > 0)
            {
                rhythmCount--;
                rhythmTimes.Add(300 + random.Next(8) * 100);
            }

            //rhythmTimes.Add(100);
            //rhythmTimes.Add(1000);
            //rhythmTimes.Add(1000);
            //rhythmTimes.Add(300);

            totalRhythmTime = 0;
            foreach (var rhythmTime in rhythmTimes)
            {
                totalRhythmTime += rhythmTime;
            }
        }

        ~Him()
        {
            foreach (var follower in followers)
            {
                follower.him = null;
            }
            followers.Clear();
        }

        public override void Update(GameTime gameTime)
        {

            currentRhythmElapsedTime += gameTime.ElapsedGameTime.Milliseconds;

            while (currentRhythmElapsedTime > rhythmTimes[currentRhythmIndex])
            {
                currentRhythmElapsedTime -= rhythmTimes[currentRhythmIndex];
                currentRhythmIndex++;
                if (currentRhythmIndex >= rhythmTimes.Count)
                {
                    currentRhythmIndex = 0;
                }
            }

            bool wasKeyDown = isKeyDown;
            isKeyDown = currentRhythmIndex % 2 == 1;

            if (!wasKeyDown && isKeyDown)
            {
                ss.SpeakAsync(voice);
            }
            if (wasKeyDown && !isKeyDown)
            {
                ss.SpeakAsyncCancelAll();
            }



            base.Update(gameTime);
        }


        public override void Draw(GameTime gameTime)
        {

            double lengthDivider = 1;

            //int width = (int)talkBubbleSize.X;
            //int height = (int)talkBubbleSize.Y;
            const int padding = 50;
            double angleOffset = angle - MathHelper.Pi / 2;
            Vector2 direction = new Vector2((float)Math.Cos(angleOffset), (float)Math.Sin(angleOffset));
            Vector2 position = screenCenter + direction * DrawPositionRadius;
            //Vector2 position = new Vector2(100, 100);
            bool isRightSide = angle % (Math.PI * 2) < Math.PI;
            //position.X = isRightSide ? this.Game.GraphicsDevice.Viewport.Width - width - padding : padding;

            int width = (int)talkBubbleSize.X;
            int height = (int)talkBubbleSize.Y;
            position.X = isRightSide ? this.Game.GraphicsDevice.Viewport.Width - width - padding : padding;


            int totalRhythmTime = 0;
            foreach (int rhythmTime in rhythmTimes)
            {
                totalRhythmTime += rhythmTime;
            }
            int trueWidth = 0;
            foreach (int rhythmTime in rhythmTimes)
            {
                trueWidth += (int)(1.0 * width * rhythmTime / totalRhythmTime);
            }
            
            {
                spriteBatch.Draw(spriteTextureWhite,
                    new Rectangle((int)position.X - 1, (int)position.Y - 1, trueWidth + 2, height + 2),
                    null,
                    Color.Black, 0, Vector2.Zero, SpriteEffects.None, 0);
            }

            

            {
                bool isDown = false;
                Vector2 positionTemp = position;

                foreach (int rhythmTime in rhythmTimes)
                {
                    Color color = this.color;
                    int length = (int)(rhythmTime / lengthDivider);
                    if (isDown)
                    {
                        color = color.Brighten();
                    }

                    int subWidth = (int)(1.0 * width * rhythmTime / totalRhythmTime);

                    spriteBatch.Draw(spriteTextureWhite,
                        new Rectangle((int)positionTemp.X, (int)positionTemp.Y, subWidth, height),
                        null,
                        color, 0, Vector2.Zero, SpriteEffects.None, 0);

                    positionTemp.X += subWidth;
                    isDown = !isDown;
                }
            }

            {
                Color color = this.color;
                color.A = 0;

                int currentRhytmTime = 0;
                for (int i = 0; i < rhythmTimes.Count; i++)
                {
                    int rhythmTime = rhythmTimes[i];
                    if (i < currentRhythmIndex)
                        currentRhytmTime += rhythmTime;
                    else if (i == currentRhythmIndex)
                        currentRhytmTime += currentRhythmElapsedTime;
                    else
                        break;
                }

                //int length = (int)(currentRhytmTime / lengthDivider);
                int leftPadding = (int)(1.0 * width * currentRhytmTime / totalRhythmTime);
                
                int pointerWidth = 10;
                if (leftPadding + pointerWidth > trueWidth)
                {
                    pointerWidth -= leftPadding + pointerWidth - trueWidth;
                }
                if (leftPadding < pointerWidth / 2)
                {
                    //width -= width / 2 - length;
                }
                spriteBatch.Draw(spriteTextureWhite,
                    new Rectangle((int)position.X + leftPadding, (int)position.Y, pointerWidth, height),
                    null,
                    color, 0, Vector2.Zero, SpriteEffects.None, 0);
            }

            base.Draw(gameTime);
        }



        protected override int DrawRectangleSize
        {
            get { return 130; }
        }
        protected override int  DrawPositionRadius
        {
            get { return 200; }
        }
        public override int DisappearTimeInSeconds
        {
            get { return 10 + 3; } // +3 for initial follow message/order
        }
        
    }
}
