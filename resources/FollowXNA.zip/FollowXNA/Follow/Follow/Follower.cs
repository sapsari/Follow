﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Follow
{
    // TODO, renk listesi çıkar
    public class Follower : Dude
    {


        public Keys key;
        public Him him;
        
        Queue<bool> hasFollowed = new Queue<bool>();
        Queue<int> followTimes = new Queue<int>();
        int totalFollowTime = 0;
        int totalMissTime = 0;

        public Follower(Game game, SpriteBatch spriteBatch, GameTime gameTime, List<Dude> others, Keys key, Him him)
            :base(game, spriteBatch, gameTime, others)
        {
            this.key = key;
            this.him = him;
            him.followers.Add(this);

            message = String.Format(Common.followerIntroductionMessages.NextRandomMessage(), key.ToString());
        }

        public override void Draw(GameTime gameTime)
        {
            base.Draw(gameTime);
        }

        public override void Update(GameTime gameTime)
        {
            UpdateFollow(gameTime);
            ChangeColor();

            base.Update(gameTime);
        }

        void UpdateFollow(GameTime gameTime)
        {
            if (him == null) return;

            if (totalFollowTime + totalMissTime > him.totalRhythmTime) // if more than a sec
            {
                bool wasFollowing = hasFollowed.Dequeue();
                int time = followTimes.Dequeue();

                if (wasFollowing)
                    totalFollowTime -= time;
                else
                    totalMissTime -= time;
            }

            if (him.isKeyDown == isKeyDown)
            {
                hasFollowed.Enqueue(true);
                followTimes.Enqueue(gameTime.ElapsedGameTime.Milliseconds);
                totalFollowTime += gameTime.ElapsedGameTime.Milliseconds;
            }
            else
            {
                hasFollowed.Enqueue(false);
                followTimes.Enqueue(gameTime.ElapsedGameTime.Milliseconds);
                totalMissTime += gameTime.ElapsedGameTime.Milliseconds;
            }
        }

        void ChangeColor()
        {
            if (isKeyDown)
            {
                Color target;
                if (him.isKeyDown == isKeyDown)
                {
                    target = him.originalColor;
                }
                else
                {
                    target = this.originalColor;
                }

                if (color.R > target.R)
                    color.R--;
                if (color.R < target.R)
                    color.R++;
                if (color.G > target.G)
                    color.G--;
                if (color.G < target.G)
                    color.G++;
                if (color.B > target.B)
                    color.B--;
                if (color.B < target.B)
                    color.B++;
            }

        }


        /// <summary>
        /// if > .9 its nice follow
        /// if > .8 its bad follow
        /// if < .8 no follow
        /// </summary>
        public double FollowRatio
        {
            get
            {
                if (totalFollowTime + totalMissTime == 0)
                    return 0;
                else
                    return 1.0 * totalFollowTime / (totalFollowTime + totalMissTime);
            }
        }
        

        protected override int DrawRectangleSize
        {
            get { return 100; }
        }
        protected override int DrawPositionRadius
        {
            get { return 180; }
        }
        public override int DisappearTimeInSeconds
        {
            get { return 5; }
        }
    

    }
}
