﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Follow
{
    // TODO, renk listesi çıkar
    public abstract class Dude : DrawableGameComponent
    {
        

        public static Random random = new Random();
        public static Vector2 screenCenter;

        public bool isKeyDown;
        public double angle;
        public readonly Color originalColor;
        protected Color color;
        public double lastKeyDownTimeInSeconds;

        public String message;
        double creationTime;
        protected Vector2 talkBubbleSize;

        protected SpriteBatch spriteBatch;
        Texture2D spriteTextureUp, spriteTextureDown;
        protected Texture2D spriteTextureWhite;
        SpriteFont font1;

        protected Dude(Game game, SpriteBatch spriteBatch, GameTime gameTime, List<Dude> others)
            : base(game)
        {
            this.spriteBatch = spriteBatch;

            isKeyDown = false;
            {
                //angle = random.NextDouble() * MathHelper.Pi * 2;
                angle = Common.NextFollowerAngle(others);
            }

            if (gameTime == null)
                creationTime = 0;
            else
                creationTime = gameTime.TotalGameTime.TotalSeconds;


            {
                const int colorLimit = 100; // for not making it too bright/white
                color = new Color(
                    random.Next(colorLimit) * (random.Next(3) == 1 ? 5 / 2 : 1),
                    random.Next(colorLimit) * (random.Next(3) == 1 ? 5 / 2 : 1),
                    random.Next(colorLimit) * (random.Next(3) == 1 ? 5 / 2 : 1));
                originalColor = color;
            }

            if (gameTime == null)
                lastKeyDownTimeInSeconds = 0;
            else
                lastKeyDownTimeInSeconds = gameTime.TotalGameTime.TotalSeconds;

            LoadContent();
        }

        protected override void LoadContent()
        {
            spriteTextureUp = Game.Content.Load<Texture2D>("dude up");
            spriteTextureDown = Game.Content.Load<Texture2D>("dude down");
            spriteTextureWhite = Game.Content.Load<Texture2D>("white");

            // Create a new SpriteBatch, which can be used to draw textures.
            font1 = Game.Content.Load<SpriteFont>("SpriteFont1");

            base.LoadContent();
        }

        int counter = 0;
        public override void Draw(GameTime gameTime)
        {
            //int DrawPositionRadius = 180;
            double angleOffset = angle - MathHelper.Pi / 2;
            Vector2 direction = new Vector2((float)Math.Cos(angleOffset), (float)Math.Sin(angleOffset));
            Vector2 position = screenCenter + direction * DrawPositionRadius;

            const int frameCount = 8;
            const int frameWidth = 200;
            Vector2 origin;
            origin.X = spriteTextureUp.Width / 2 / frameCount;
            origin.Y = spriteTextureUp.Height / 2;


            counter++;

            Texture2D drawingTexture = spriteTextureUp;
            Color color = this.CurrentColor;
            if (isKeyDown)
            {
                drawingTexture = spriteTextureDown;
            }

            // make it transparent in the last second before disapearing
            if (gameTime.TotalGameTime.TotalSeconds - lastKeyDownTimeInSeconds > DisappearTimeInSeconds - 1)
            {
                color.A = (byte)((1.0 - gameTime.TotalGameTime.TotalSeconds - lastKeyDownTimeInSeconds - DisappearTimeInSeconds) * byte.MaxValue);
            }

            spriteBatch.Draw(drawingTexture,
                new Rectangle((int)position.X, (int)position.Y, DrawRectangleSize, DrawRectangleSize),
                new Rectangle(counter / 10 % frameCount * frameWidth, 0, frameWidth, spriteTextureUp.Height),
                color, (float)angle, origin, SpriteEffects.None, 0);


            if (gameTime.TotalGameTime.TotalSeconds - creationTime < 3)
            {

                String text = message;
                Vector2 textSize = font1.MeasureString(text);


                bool isRightSide = angle % (Math.PI * 2) < Math.PI;
                Vector2 talkBubblePosition = position + direction * 0;


                int width = (int)textSize.X + 20;
                int height = (int)textSize.Y;
                const int padding = 50;
                talkBubbleSize = new Vector2(width, height);

                talkBubblePosition.X = isRightSide ? this.Game.GraphicsDevice.Viewport.Width - width - padding : padding;

                spriteBatch.Draw(spriteTextureWhite,
                    new Rectangle(isRightSide ? this.Game.GraphicsDevice.Viewport.Width - width - padding - 1 : padding - 1,
                        (int)talkBubblePosition.Y - 1, width + 2, height + 2),
                    null,
                    Color.Black, 0, Vector2.Zero, SpriteEffects.None, 0);


                spriteBatch.Draw(spriteTextureWhite,
                    new Rectangle(isRightSide ? this.Game.GraphicsDevice.Viewport.Width - width - padding : padding,
                        (int)talkBubblePosition.Y, width, height),
                    null,
                    color, 0, Vector2.Zero, SpriteEffects.None, 0);


                talkBubblePosition += new Vector2(width / 2, height / 2);
                spriteBatch.DrawString(font1, text, talkBubblePosition, Color.White, 0, textSize / 2, 1.0f, SpriteEffects.None, 0.5f);

            }

            base.Draw(gameTime);
        }

        public override void Update(GameTime gameTime)
        {
            angle += gameTime.ElapsedGameTime.Milliseconds / 5000.0;

            base.Update(gameTime);
        }


        protected abstract int DrawRectangleSize { get; }
        protected abstract int DrawPositionRadius { get; }
        public abstract int DisappearTimeInSeconds { get; }

        public Color CurrentColor
        {
            get
            {
                if (isKeyDown)
                    return color.Brighten();
                else
                    return color;
            }
        }
        public Color CurrentColor2
        {
            get
            {
                if (!isKeyDown)
                    return color.Brighten();
                else
                    return color;
            }
        }
        //public Color OriginalColor
        //{
        //    get
        //    {
        //        if (!isKeyDown)
        //            return color.Brighten();
        //        else
        //            return color;
        //    }
        //}


    }
}
